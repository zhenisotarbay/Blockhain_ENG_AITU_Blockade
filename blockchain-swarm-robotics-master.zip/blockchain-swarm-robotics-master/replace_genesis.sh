sed -e "s|ADDRESS|"$1"|g" "/home/vstrobel/genesis/genesis_template.json" > "/home/vstrobel/genesis/genesis${2}.json"
